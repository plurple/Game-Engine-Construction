#pragma once
#include <unordered_map>
#include "Sprite.h"



class Graphics
{

public:
	Graphics();
	~Graphics();
	void clearScreen(); // function to clear screen
	void changePixel(BYTE *pnter, HAPI_TColour colour); // function to change a pixels colour
	void CreateSprite(const std::string &fileName, const std::string &uniqueName, int numberOfFramesX = 1, int numberOfFramesY = 1); //creates sprite with a default number of frames as 1
	void RenderAlphaSprite(const std::string &uniqueName, int screenx, int screeny, int frameNumber = 0); //renders the sprite with alpha chanels and assuming there is only 1 frame and so on frame 0.
	void RenderSprite(const std::string &uniqueName, int screenx, int screeny, int frameNumber = 0); // renders the sprite with no alpha and assumes 1 frame and so on frame 0.
	bool WithinMiddle(const std::string &uniqueName, int screenx, int screeny); //check to see if in middle of the screen.

private:
	std::unordered_map<std::string, Sprite*> spriteMap; //collection of sprites that have been loaded.
	int screenWidth{ 800 };
	int screenHeight{ 600 };
	BYTE *screen = nullptr;
	Rectangle screenSpace{ screenWidth, screenHeight }; //creates the rectangle of the screen to check if sprites are within this to draw them or not.
	
};

