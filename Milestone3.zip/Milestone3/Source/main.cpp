/*
	HAPI Start
	----------
	This solution contains an already set up HAPI project and this main file

	The directory structure and main files are:

	HAPI_Start - contains the Visual Studio solution file (.sln)
		HAPI_Start - contains the Visual Studio HAPI_APP project file (.vcxproj) and source code
			HAPI - the directory with all the HAPI library files
			Data - a place to put your data files with a few sample ones provided

	Additionally in the top directory there is a batch file for creating a redistributable Demo folder

	For help using HAPI:
	https://scm-intranet.tees.ac.uk/users/u0018197/hapi.html
*/

// Include the HAPI header to get access to all of HAPIs interfaces

#include <stdlib.h>
#include <time.h>
#include <string>
#include "Graphics.h"


//and enum class to control which direction the player is facing and to control the animation start frame for each direction
enum Direction
{
	North,
	NorthEast = 8,
	East = 16,
	SouthEast = 24,
	South = 32,
	SouthWest = 40,
	West = 48,
	NorthWest = 56
};

int animate(int frameOffset);


// Every HAPI program has a HAPI_Main as an entry point
// When this function exits the program will close down
void HAPI_Main()
{
	//creates an instance of the graphics so the window is created and you can draw to it.
	Graphics display;
	
	std::string background = "background";
	std::string player = "devil";
	display.CreateSprite("data/space.png", background); //creates a background sprite.
	display.CreateSprite("data/devil.png", player, 8, 8); // creates a player sprite.
	
	float playerX{ 0.0f }, playerY{ -5.0f };
	float playerSpeed{ 1.0f };	//works out the diagonal speed of the player to avoid going faster in the diagonal direction.
	float diagonalSpeed = sqrt((playerSpeed * playerSpeed) * 2.0f) / 2.0f;
	Direction playerDirection = Direction::South;
	int frameOffset{ 0 };
	int frameNumber{ playerDirection };
	//to get keyboard data
	const HAPI_TKeyboardData &keyData = HAPI.GetKeyboardData();
	

	//the game loop
	while (HAPI.Update())
	{
		//shows the fps in the top left corner
		HAPI.SetShowFPS(true);
		//gets the controller data.
		const HAPI_TControllerData &data = HAPI.GetControllerData(0);

		
		//checks to see if a control is attached.
		if (data.isAttached)
		{
			//allows the user to move the player with the left analogue stick.
			if (data.analogueButtons[HK_ANALOGUE_LEFT_THUMB_X] < -10000)
			{
				if (data.analogueButtons[HK_ANALOGUE_LEFT_THUMB_Y] > 10000)
				{
					playerX -= diagonalSpeed;
					playerY -= diagonalSpeed;
					playerDirection = Direction::NorthWest;
					frameOffset = animate(frameOffset);
				}
				else if (data.analogueButtons[HK_ANALOGUE_LEFT_THUMB_Y] < -10000)
				{
					playerX -= diagonalSpeed;
					playerY += diagonalSpeed;
					playerDirection = Direction::SouthWest;
					frameOffset = animate(frameOffset);
				}
				else
				{
					playerX -= playerSpeed;
					playerDirection = Direction::West;
					frameOffset = animate(frameOffset);
				}
			}
			else if (data.analogueButtons[HK_ANALOGUE_LEFT_THUMB_X] > 10000)
			{
				if (data.analogueButtons[HK_ANALOGUE_LEFT_THUMB_Y] > 10000)
				{
					playerX += diagonalSpeed;
					playerY -= diagonalSpeed;
					playerDirection = Direction::NorthEast;
					frameOffset = animate(frameOffset);
				}
				else if (data.analogueButtons[HK_ANALOGUE_LEFT_THUMB_Y] < -10000)
				{
					playerX += diagonalSpeed;
					playerY += diagonalSpeed;
					playerDirection = Direction::SouthEast;
					frameOffset = animate(frameOffset);
				}
				else
				{
					playerX += playerSpeed;
					playerDirection = Direction::East;
					frameOffset = animate(frameOffset);
				}
			}
			else if (data.analogueButtons[HK_ANALOGUE_LEFT_THUMB_Y] > 10000)
			{
				playerY -= playerSpeed;
				playerDirection = Direction::North;
				frameOffset = animate(frameOffset);
			}
			else if (data.analogueButtons[HK_ANALOGUE_LEFT_THUMB_Y] < -10000)
			{
				playerY += playerSpeed;
				playerDirection = Direction::South;
				frameOffset = animate(frameOffset);
			}
			//checks if the player sprite is within the middle and if so sets the rumble of the atached controller.
			if (display.WithinMiddle(player, (int)playerX, (int)playerY))
			{
				HAPI.SetControllerRumble(0, 50000, 50000);
			}
			else
			{
				HAPI.SetControllerRumble(0, 0, 0);
			}
		}


		if (keyData.scanCode['A'])
			if (keyData.scanCode['W'])
			{
				playerX -= diagonalSpeed;
				playerY -= diagonalSpeed;
				playerDirection = Direction::NorthWest;
				frameOffset = animate(frameOffset);
			}
			else if (keyData.scanCode['S'])
			{
				playerX -= diagonalSpeed;
				playerY += diagonalSpeed;
				playerDirection = Direction::SouthWest;
				frameOffset = animate(frameOffset);
			}
			else
			{
				playerX -= playerSpeed;
				playerDirection = Direction::West;
				frameOffset = animate(frameOffset);
			}
		else if (keyData.scanCode['D'])
			if (keyData.scanCode['W'])
			{
				playerX += diagonalSpeed;
				playerY -= diagonalSpeed;
				playerDirection = Direction::NorthEast;
				frameOffset = animate(frameOffset);
			}
			else if (keyData.scanCode['S'])
			{
				playerX += diagonalSpeed;
				playerY += diagonalSpeed;
				playerDirection = Direction::SouthEast;
				frameOffset = animate(frameOffset);
			}
			else
			{
				playerX += playerSpeed;
				playerDirection = Direction::East;
				frameOffset = animate(frameOffset);
			}
		else if (keyData.scanCode['W'])
		{
			playerY -= playerSpeed;
			playerDirection = Direction::North;
			frameOffset = animate(frameOffset);
		}
		else if (keyData.scanCode['S'])
		{
			playerY += playerSpeed;
			playerDirection = Direction::South;
			frameOffset = animate(frameOffset);
		}

		frameNumber = playerDirection + frameOffset;

		//clears the screen each frame to allow the next frame to be drawn.
		display.clearScreen();

		display.RenderSprite(background, 0, 0); //draws the background.
		display.RenderAlphaSprite(player, (int)playerX, (int)playerY, frameNumber); //draws the player.

	}


}


//a small function to advance the animation frames within an animation loop and make sure it doesn't loop to next animation cycle.
int animate(int frameOffset)
{
	static DWORD lastFrameUpdateTime{ 0 };

	DWORD time = HAPI.GetTime();
	if (time - lastFrameUpdateTime > 100)
	{

		frameOffset++;
		lastFrameUpdateTime = time;
	}

	if (frameOffset > 7)
	{
		frameOffset = 0;
	}
	
	return frameOffset;
}


