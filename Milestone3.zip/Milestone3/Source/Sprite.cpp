#include "Sprite.h"



Sprite::Sprite(const std::string &filename, int framesX, int framesY)
{
	if (!HAPI.LoadTexture(filename, &spritePnter, spriteWidth, spriteHeight))
	{
		HAPI_UserResponse responce;
		HAPI.UserMessage("Texture not found", "Missing Texture", HAPI_ButtonType::eButtonTypeOk, &responce);
		if (responce == HAPI_UserResponse::eUserResponseOk)
			HAPI.Close();
	}
	frameWidth = spriteWidth / framesX;
	frameHeight = spriteHeight / framesY;
	numberOfFramesX = framesX;
	numberOfFramesY = framesY;
	Rectangle temp(frameWidth, frameHeight);
	frameRectangle = temp;
	
}


Sprite::~Sprite()
{
	delete[] spritePnter;
}

Rectangle Sprite::CreateRectangle()
{
	return frameRectangle;
}


void Sprite::AlphaBlit(BYTE *screen, int screenWidth, int screenX, int screenY, Rectangle clippedRect, int frameNumber)
{
	unsigned int screenOffset = (screenX + screenY * screenWidth) * 4;
	BYTE *pnter = screen + screenOffset;
	int rectangleWidth = clippedRect.CalculateWidth();
	int rectangleHeight = clippedRect.CalculateHeight();
	//an if statment to check still within the sprite sheet if not to wrap around. temporary fix.
	if (frameNumber >= (numberOfFramesX*numberOfFramesY))
	{
		frameNumber = frameNumber % (numberOfFramesX * numberOfFramesY);
	}
	int numberX = frameNumber % numberOfFramesX; //to work out the x frame offset.
	int numberY = std::max(frameNumber / numberOfFramesY, 0); //to work out the y frame offset.
	clippedRect.Translate((numberX * frameWidth), (numberY * frameHeight)); //translates the rectangle to the correct frame to draw.
	unsigned int frameOffset = ((clippedRect.left + clippedRect.top * spriteWidth) * 4);
	BYTE *texturePnter = spritePnter + frameOffset;
	BYTE blue;
	BYTE green;
	BYTE red;
	BYTE alpha;
	

	for (int i = 0; i < rectangleHeight; i++)
	{
		for (int j = 0; j < rectangleWidth; j++)
		{
			blue = texturePnter[0];
			green = texturePnter[1];
			red = texturePnter[2];
			alpha = texturePnter[3];

			if (alpha == 255)
			{
				memcpy(pnter, texturePnter, 4);
			}
			else if (alpha != 0)
			{
				pnter[0] = pnter[0] + ((alpha * (blue - pnter[0])) >> 8);
				pnter[1] = pnter[0] + ((alpha * (green - pnter[0])) >> 8);
				pnter[2] = pnter[0] + ((alpha * (red - pnter[0])) >> 8);
			}
			pnter += 4;
			texturePnter += 4;
		}

		pnter += (screenWidth - rectangleWidth) * 4;
		texturePnter += (spriteWidth - rectangleWidth) * 4;
	}
}

void Sprite::Blit(BYTE *screen, int screenWidth, int screenX, int screenY,Rectangle clippedRect, int frameNumber)
{
	unsigned int offset = (screenX + screenY * screenWidth) * 4;
	BYTE *pnter = screen + offset;
	int rectangleWidth = clippedRect.CalculateWidth();
	int rectangleHeight = clippedRect.CalculateHeight();
	//an if statment to check still within the sprite sheet if not to wrap around. temporary fix.
	if (frameNumber >= (numberOfFramesX*numberOfFramesY))
	{
		frameNumber = frameNumber % (numberOfFramesX * numberOfFramesY);
	}
	int numberX = frameNumber % numberOfFramesX; //to work out the x frame offset.
	int numberY = std::max(frameNumber - numberOfFramesX, 0); //to work out the y frame offset.
	clippedRect.Translate((numberX * frameWidth), (numberY * frameHeight)); //translates the rectangle to the correct frame to draw.
	unsigned int frameOffset = ((clippedRect.left + clippedRect.top * spriteWidth) * 4);
	BYTE *texturePnter = spritePnter + frameOffset;

	for (int i = 0; i < rectangleHeight; i++)
	{

		memcpy(pnter, texturePnter, rectangleWidth * 4);

		pnter += screenWidth * 4;
		texturePnter += spriteWidth * 4;
	}

}