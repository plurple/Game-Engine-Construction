#pragma once
#include <HAPI_lib.h>
#include "Rectangle.h"

using namespace HAPISPACE;

class Sprite
{
public:
	Sprite(const std::string &filename, int framesX = 1, int framesY = 1); //default to 1 sprite and specify if there are more than one.
	~Sprite();
	void AlphaBlit(BYTE *screen, int screenWidth, int posX, int posY, Rectangle clippedRect, int frameNumber);
	void Blit(BYTE *screen, int screenWidth, int screenX, int screenY, Rectangle clippedRect, int frameNumber);
	Rectangle CreateRectangle(); //creates rectangle to allow clipping and collision.
	
	

private:
	int spriteWidth, spriteHeight;
	BYTE *spritePnter{ nullptr };
	int frameWidth, frameHeight, numberOfFramesX, numberOfFramesY; //information to work with sprite sheets and animation.
	Rectangle frameRectangle{ 0, 0 };
};

