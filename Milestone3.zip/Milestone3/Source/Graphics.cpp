#include "Graphics.h"



Graphics::Graphics()
{
	//create the window
	if (!HAPI.Initialise(screenWidth, screenHeight))
	{
		return;
	}
	screen = HAPI.GetScreenPointer(); // gets the pointer to the start of the screen.
	
}


Graphics::~Graphics()
{
	//deletes the collection of sprites.
	for (std::unordered_map<std::string, Sprite*>::iterator MapItor = spriteMap.begin(); MapItor != spriteMap.end(); ++MapItor)
	{
		Sprite *Value = MapItor->second;
		delete Value;
	}

}

void Graphics::clearScreen()
{
	//clears the screen to black.
	BYTE * pnter = screen;
	memset(pnter, 0, screenHeight * screenWidth * 4);
}

void Graphics::changePixel(BYTE *pnter, HAPI_TColour colour)
{
	memcpy(pnter, &colour, 4);
}


void Graphics::CreateSprite(const std::string &filename, const std::string &uniqueName, int numberOfFramesX, int numberOfFramesY)
{
	//creates a sprite and then adds it to the collection of sprites.
	Sprite *sprite = new Sprite(filename, numberOfFramesX, numberOfFramesY);
	spriteMap[uniqueName] = sprite;	

}

void Graphics::RenderAlphaSprite(const std::string &uniqueName, int screenx, int screeny, int frameNumber)
{
	//checks to make sure that the specified sprite exists.
	if (spriteMap.find(uniqueName) == spriteMap.end())
	{
		HAPI_UserResponse responce;
		HAPI.UserMessage("Sprite not found", "Missing " + uniqueName, HAPI_ButtonType::eButtonTypeOk, &responce);
		if (responce == HAPI_UserResponse::eUserResponseOk)
			HAPI.Close();
	}

	Sprite *sprite = spriteMap.at(uniqueName);
	Rectangle spriteSpace = sprite->CreateRectangle(); //creates a rectangle for the sprite for clipping purposes.

	spriteSpace.Translate(screenx, screeny); //translates the sprite to screen space.
	//checks if the sprite is completly within the screen.
	if (spriteSpace.CompletelyContains(screenSpace))
	{
		spriteSpace.Translate(-screenx, -screeny); //translates sprite back into it's own space.
		sprite->AlphaBlit(screen, screenWidth, screenx, screeny, spriteSpace, frameNumber);
	}
	//makes sure the sprite isn't completly off screen if so doesn't draw it.
	else if (!spriteSpace.CompletelyOutside(screenSpace))
	{
		spriteSpace.ClipTo(screenSpace);
		spriteSpace.Translate(-screenx, -screeny);//translates back to sprite space.
		//check if sprite is off the left side of the screen
		if (screenx < 0)
		{
			//adjusts the sprite's x position so it can move the sprite pointer.
			screenx = 0;
		}
		//check if sprite is off the top side of the screen
		if (screeny < 0)
		{
			//adjusts the sprite's y position so it can move the sprite pointer.
			screeny = 0;
		}
			
		//passes information to the sprite class so that it can be drawn.
		sprite->AlphaBlit(screen, screenWidth, screenx, screeny, spriteSpace, frameNumber);
	}
	
}


void Graphics::RenderSprite(const std::string &uniqueName, int screenx, int screeny, int frameNumber)
{
	if (spriteMap.find(uniqueName) == spriteMap.end())
	{
		HAPI_UserResponse responce;
		HAPI.UserMessage("Sprite not found", "Missing Sprite", HAPI_ButtonType::eButtonTypeOk, &responce);
		if (responce == HAPI_UserResponse::eUserResponseOk)
			HAPI.Close();
	}

	Sprite *sprite = spriteMap.at(uniqueName);
	Rectangle spriteSpace = sprite->CreateRectangle();

	spriteSpace.Translate(screenx, screeny);
	if (spriteSpace.CompletelyContains(screenSpace))
	{
		spriteSpace.Translate(-screenx, -screeny);
		sprite->Blit(screen, screenWidth, screenx, screeny, spriteSpace, frameNumber);
	}
	else if (!spriteSpace.CompletelyOutside(screenSpace))
	{
		spriteSpace.ClipTo(screenSpace);
		spriteSpace.Translate(-screenx, -screeny);
		if (screenx < 0)
		{
			
			screenx = 0;
		}
		if (screeny < 0)
		{
			
			screeny = 0;
		}
		sprite->Blit(screen, screenWidth, screenx, screeny, spriteSpace, frameNumber);
	}
}

bool Graphics::WithinMiddle(const std::string &uniqueName, int screenx, int screeny)
{
	if (spriteMap.find(uniqueName) == spriteMap.end())
	{
		HAPI_UserResponse responce;
		HAPI.UserMessage("Sprite not found", "Missing Sprite", HAPI_ButtonType::eButtonTypeOk, &responce);
		if (responce == HAPI_UserResponse::eUserResponseOk)
			HAPI.Close();
	}
	Rectangle spriteSpace = spriteMap.at(uniqueName)->CreateRectangle();
	Rectangle middle{ screenWidth / 4, screenHeight / 4 };
	//locates the startt of the bounding box of the middle to check if the sprite is within it.
	int middleX = screenWidth / 2 - middle.CalculateWidth() /2 ;
	int middleY = screenHeight / 2 - middle.CalculateHeight() / 2;
	
	spriteSpace.Translate(screenx, screeny); //translates the sprite to the screen space.
	middle.Translate(middleX, middleY); //translates the middle box to screen space.
	
	//checks to see if the sprite has crossed the border of the middle box.
	if (!spriteSpace.CompletelyOutside(middle))
	{
		return true;
	}
	return false;
}

