/*
	HAPI Start
	----------
	This solution contains an already set up HAPI project and this main file
	
	The directory structure and main files are:

	HAPI_Start - contains the Visual Studio solution file (.sln)
		HAPI_Start - contains the Visual Studio HAPI_APP project file (.vcxproj) and source code
			HAPI - the directory with all the HAPI library files
			Data - a place to put your data files with a few sample ones provided

	Additionally in the top directory there is a batch file for creating a redistributable Demo folder

	For help using HAPI:
	https://scm-intranet.tees.ac.uk/users/u0018197/hapi.html
*/

// Include the HAPI header to get access to all of HAPIs interfaces
#include <HAPI_lib.h>
#include <stdlib.h>
#include <time.h>

// HAPI itself is wrapped in the HAPISPACE namespace
using namespace HAPISPACE;

//structure to hold the stars position and colour.
struct Coordinates
{
	int x, y;
	float z;
	HAPI_TColour colour;
};

void clearScreen(int height, int Width, BYTE* screen, HAPI_TColour colour); // function to clear screen
void changePixel(BYTE *pnter, HAPI_TColour colour); // function to change a pixels colour
void createStars(Coordinates *stars, int i, int screenWidth, int screenHeight); //function to create the field of stars
void renderStars(Coordinates *stars, int numStars, int eyedistance, int screenWidth, int screenHeight, BYTE* screen); // function to render the stars
void moveStars(Coordinates *stars, int numStars, int screenWidth, int screenHeight, float dz); //function to move the stars towards the screen

// Every HAPI program has a HAPI_Main as an entry point
// When this function exits the program will close down
void HAPI_Main()
{
	int screenWidth{ 800 };
	int screenHeight{ 600 };

	
	const int numStars{ 1000 };


		//create teh window
		if (!HAPI.Initialise(screenWidth, screenHeight))
		{
			return;
		}

		//array of star objects
		Coordinates stars[numStars];

		
		//pointer to the top left pixel
		BYTE* screen = HAPI.GetScreenPointer();

		int x{ 0 }, y{ 0 };
		unsigned int offset = (x + y * screenWidth) * 4;
		BYTE *pnter = screen + offset;
		int eyedistance{ 100 };
		HAPI_TColour colour(0, 0, 0, 0);
		float dz{ 0.5 };

		//loop to create all of the stars
		for (int i = 0; i < numStars; i++)
		{
			createStars(stars, i, screenWidth, screenHeight);
		}

		//the game loop
		while (HAPI.Update())
		{
			//shows the fps in the top left corner
			HAPI.SetShowFPS(true);

			//to get keyboard data
			const HAPI_TKeyboardData &keyData = HAPI.GetKeyboardData();

			//to increase and decrease the speed that the stars are moving towards you.
			if (keyData.scanCode[HK_UP])
				dz += 0.01;
			else if (keyData.scanCode[HK_DOWN])
				dz -= 0.01;
			//to increase and decrease the eyedistance
			if (keyData.scanCode[HK_LEFT])
			{
				eyedistance -= 1;
				if (eyedistance <= 0)
					eyedistance = 1;
			}
			else if (keyData.scanCode[HK_RIGHT])
				eyedistance += 1;

			clearScreen(screenHeight, screenWidth, screen, colour);
			moveStars(stars, numStars, screenWidth, screenHeight, dz);
			renderStars(stars, numStars, eyedistance, screenWidth, screenHeight, screen);

		}
	
}

void clearScreen(int height, int Width, BYTE* screen, HAPI_TColour colour)
{

	for (int i = 0; i < height * Width * 4; i += 4)
	{
		screen[i] = colour.red;
		screen[i + 1] = colour.green;
		screen[i + 2] = colour.blue;
	}

}

void changePixel(BYTE *pnter, HAPI_TColour colour)
{
	memcpy(pnter, &colour, 4);
}

void createStars(Coordinates *stars, int i, int screenWidth, int screenHeight)
{
	//randomly sets the stars position in 3d space and a random colour
	stars[i].x = rand() % screenWidth;
	stars[i].y = rand() % screenHeight;
	stars[i].z = (float) (rand() % 500);
	stars[i].colour.red = rand() % 255;
	stars[i].colour.green = rand() % 255;
	stars[i].colour.blue = rand() % 255;	
}

void renderStars(Coordinates *stars, int numStars, int eyedistance, int screenWidth, int screenHeight, BYTE* screen)
{
	int screenX, screenY;
	for (int i = 0; i < numStars; i++)
	{
		//adjusts the 3d coordinates to there positions on the screen.
		screenX = ((eyedistance * (stars[i].x - (screenWidth / 2))) / (eyedistance + stars[i].z)) + (screenWidth / 2);
		screenY = ((eyedistance * (stars[i].y - (screenHeight / 2))) / (eyedistance + stars[i].z)) + (screenHeight / 2);
		unsigned int offset = (screenX + screenY * screenWidth) * 4;
		BYTE *pnter = screen + offset;
		//checks that the pixel is being drawn on the screen
		if(screenY < screenHeight && screenY > 0)
		changePixel(pnter, stars[i].colour);
	}
}

void moveStars(Coordinates *stars, int numStars, int screenWidth, int screenHeight, float dz)
{
	for (int i = 0; i < numStars; i++)
	{
		//reduces z to move the stars towards the user.
		

		stars[i].z -= dz;

		//creates a new star once the stars moves off the screen
		if (stars[i].z <= 0)
		{
			createStars(stars, i, screenWidth, screenHeight);
		}
	}
 }
